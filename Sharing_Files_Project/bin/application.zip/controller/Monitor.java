package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Monitor implements SharingSystem {
	
	private static Monitor monitor_instance = null;
	private static int counter;
	private final String PATH = "D:\\Dokumenty\\College\\Year 3\\Java - Distributed Systems Programming\\Server\\";
	private String[] fileNames = null;
	
	private Monitor()
	{
		counter = 0;
	}

	public static synchronized Monitor getInstance()
	{
		if(monitor_instance == null)
		{
			monitor_instance = new Monitor();
		}
		
		counter++;
		System.out.println("Counter: " + counter);
		return monitor_instance;
	}
	
	@Override
	public String[] getNames() 
	{
		File dir = new File(PATH);
		if(dir.isDirectory())
		{
			fileNames = dir.list();
		}
		return fileNames;
	}

	@Override
	public boolean copyFile(String fileName, File dest) throws IOException {
		File file = new File(PATH + fileName);
		dest.createNewFile();
		InputStream input = null;
		OutputStream output = null;
		try 
		{
			try 
			{
				input = new FileInputStream(file);
			} 
			catch (FileNotFoundException e) 
			{
				e.printStackTrace();
			}
			
			try 
			{
				output = new FileOutputStream(dest);
			} 
			catch (FileNotFoundException e) 
			{
				e.printStackTrace();
			}
			byte[] buf = new byte[1024];
			int bytesRead;
			
			while ((bytesRead = input.read(buf)) > 0) 
			{
				output.write(buf, 0, bytesRead);
			}
		} 
		finally 
		{
			input.close();
			output.close();
		}

		return false;
	}

	@Override
	public boolean checkForChange() {
		String[] oldNames = new String[fileNames.length];
		for(int i = 0; i < fileNames.length; i++)
		{
			oldNames[i] = fileNames[i];
		}
		getNames();
		boolean diff = false;
		int j = 0;
		while(!diff && j < fileNames.length)
		{
			if(oldNames[j] != fileNames[j])
			{
				diff = true;
			}
		}
		return true;
	}

	public int getCounter()
	{
		return counter;
	}
	
	public void reduceCounter()
	{
		counter--;
		System.out.println("reduced to: " + counter);
	}
}
