package application;

import java.io.File;
import java.io.IOException;

import controller.Monitor;
import javafx.application.Application;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;


public class Main extends Application {
	
	private BorderPane root;
	private GridPane pane;
	private Scene scene;
	private Monitor resourceFolderMonitor;
	private File dest;
	private String output = "";
	private String fileName;
	
	@Override
	public void start(Stage primaryStage) {
		
		resourceFolderMonitor = Monitor.getInstance();
		
		try 
		{
			pane = new GridPane();
			VBox box = new VBox(5);
			String[] names = resourceFolderMonitor.getNames();
			for(int i = 0; i < names.length; i++)
			{
				Button tmp = new Button(names[i]);
				tmp.setPrefSize(200, 50);
				box.getChildren().add(tmp);
				tmp.setOnAction(e->{
					fileName = tmp.getText();
				});
				output += names[i] + "\n";
			}
			Text text = new Text(output);
			
			DirectoryChooser chooser = new DirectoryChooser();
			chooser.setTitle("Select Location");
			
			Button selectDestButton = new Button("Select Save Location");
			selectDestButton.setOnAction(e->{
				dest = chooser.showDialog(primaryStage);
				text.setText(output);
				if(dest != null)
				{
					text.setText(text.getText() + "\nSelected Location: " + dest.getPath());
				}
			});
			
			Button copyButton = new Button("Confirm Copy");
			/*copyButton.setOnAction(e->{
				try 
				{
					resourceFolderMonitor.copyFile(fileName, dest);
				} 
				catch (IOException e1) 
				{
					e1.printStackTrace();
				}
			});*/
			box.getChildren().addAll(text, selectDestButton, copyButton);
			root = new BorderPane();
			pane.add(box, 0, 0);
			root.getChildren().add(pane);
			scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
		primaryStage.setOnCloseRequest(e->{
			resourceFolderMonitor.reduceCounter();
			primaryStage.close();
		});
		
	}
	
	public static void main(String[] args) {

		launch(args);

	}
}
